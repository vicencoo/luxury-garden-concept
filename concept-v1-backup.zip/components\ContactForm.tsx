"use client";

import { useState, type FormEvent } from "react";
import { interests } from "@/lib/content";

const field =
  "mt-2 w-full rounded-md border border-cypress/20 bg-chalk px-4 py-3 text-cypress placeholder:text-cypress/40 focus:border-cypress focus:outline-none focus-visible:outline-2 focus-visible:outline-citrus";

export default function ContactForm() {
  const [sentTo, setSentTo] = useState<string | null>(null);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    // Concept only: connect this to email or a CRM before going live.
    setSentTo(String(data.get("name") || "").split(" ")[0] || "there");
  }

  if (sentTo) {
    return (
      <div role="status" className="flex h-full flex-col justify-center rounded-lg bg-chalk p-8 md:p-12">
        <h3 className="font-display text-h3">Thanks, {sentTo}. Your request is sent.</h3>
        <p className="mt-4 max-w-[30rem] text-cypress/75">
          We will reply with prices and availability, or call you to arrange
          a site visit.
        </p>
        <button
          type="button"
          onClick={() => setSentTo(null)}
          className="mt-8 self-start font-medium underline decoration-olive/50 underline-offset-[6px]"
        >
          Send another request
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="rounded-lg bg-chalk p-6 sm:p-8 md:p-10">
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="block text-sm font-medium">
          Name
          <input name="name" required autoComplete="name" className={field} />
        </label>
        <label className="block text-sm font-medium">
          Phone
          <input name="phone" type="tel" required autoComplete="tel" className={field} />
        </label>
        <label className="block text-sm font-medium">
          Email
          <input name="email" type="email" autoComplete="email" className={field} />
        </label>
        <label className="block text-sm font-medium">
          I&apos;m interested in
          <select name="interest" defaultValue={interests[0]} className={field}>
            {interests.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>
        <label className="block text-sm font-medium sm:col-span-2">
          Delivery or property location
          <input name="location" placeholder="Town or area" className={field} />
        </label>
        <label className="block text-sm font-medium sm:col-span-2">
          Your message
          <textarea
            name="message"
            rows={4}
            placeholder="The products you want, quantities, or the garden you have in mind"
            className={`${field} resize-y`}
          />
        </label>
      </div>
      <button
        type="submit"
        className="mt-8 w-full rounded-full bg-cypress px-7 py-4 font-medium text-chalk transition-colors hover:bg-cypress-soft sm:w-auto"
      >
        Send request
      </button>
    </form>
  );
}
