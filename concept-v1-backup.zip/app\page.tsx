import Header from "@/components/Header";
import Hero from "@/components/Hero";
import CategoryStrip from "@/components/CategoryStrip";
import Shop from "@/components/Shop";
import Offer from "@/components/Offer";
import Clients from "@/components/Clients";
import Services from "@/components/Services";
import Gardens from "@/components/Gardens";
import Process from "@/components/Process";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import FloatingWhatsApp from "@/components/FloatingWhatsApp";

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <CategoryStrip />
        <Shop />
        <Offer />
        <Clients />
        <Services />
        <Gardens />
        <Process />
        <Contact />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </>
  );
}
