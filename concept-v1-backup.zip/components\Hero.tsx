import Image from "next/image";
import { images } from "@/lib/content";

export default function Hero() {
  return (
    <section id="top" className="overflow-hidden">
      <div className="mx-auto grid max-w-[1320px] gap-14 px-5 pb-16 pt-12 md:px-10 md:pt-16 lg:grid-cols-12 lg:gap-8 lg:pb-20">
        <div className="flex flex-col justify-center lg:col-span-6 lg:pr-6">
          <h1 className="settle font-display text-display text-cypress">
            Gardens that arrive already grown.
          </h1>
          <p
            className="settle mt-8 max-w-[34rem] text-lg leading-relaxed text-cypress/80"
            style={{ animationDelay: "0.25s" }}
          >
            Shop mature trees, flowering plants and handmade vases at the
            Luxury Garden nursery, or let us design and plant the whole garden
            for your villa, hotel or residence.
          </p>
          <div
            className="settle mt-10 flex flex-wrap items-center gap-x-8 gap-y-4"
            style={{ animationDelay: "0.4s" }}
          >
            <a
              href="#shop"
              className="rounded-full bg-cypress px-7 py-4 font-medium text-chalk transition-colors hover:bg-cypress-soft"
            >
              Shop the collection
            </a>
            <a
              href="#contact"
              className="font-medium text-cypress underline decoration-olive/50 decoration-1 underline-offset-[6px] transition-colors hover:decoration-cypress"
            >
              Book a site visit
            </a>
          </div>
        </div>

        <div className="relative lg:col-span-6">
          <figure className="relative ml-auto w-[82%] sm:w-[74%] lg:w-[80%]">
            <div className="arch rise relative aspect-[3/4] bg-sage/40">
              <Image
                src={images.hero}
                alt="Round swimming pool in a garden of palm trees with a pergola"
                fill
                priority
                sizes="(min-width: 1024px) 42vw, 80vw"
                className="object-cover"
              />
            </div>
            <figcaption className="mt-4 text-right text-sm text-olive">
              Pool garden with palms and a pergola
            </figcaption>
          </figure>

          <div
            className="arch rise absolute bottom-10 left-0 aspect-[3/4] w-[40%] border-[6px] border-b-0 border-lichen bg-sage/40 sm:w-[34%] lg:w-[36%]"
            style={{ animationDelay: "0.35s" }}
          >
            <Image
              src={images.heroDetail}
              alt="Lemon tree growing in a stone courtyard"
              fill
              sizes="(min-width: 1024px) 18vw, 40vw"
              className="object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
