import Image from "next/image";
import { images, whatsappLink } from "@/lib/content";
import ContactForm from "./ContactForm";

export default function Contact() {
  return (
    <section id="contact" aria-labelledby="contact-heading" className="scroll-mt-20 bg-sage/35">
      <div className="mx-auto grid max-w-[1320px] gap-14 px-5 py-24 md:px-10 lg:grid-cols-12 lg:gap-10 lg:py-32">
        <div className="lg:col-span-5">
          <h2 id="contact-heading" className="font-display text-h2">
            Ask for prices or book a site visit
          </h2>
          <p className="mt-6 max-w-[30rem] text-cypress/80">
            Send a few details for a price on any product, or to arrange a
            site visit for a garden project. You can also visit the nursery to
            see everything in person.
          </p>

          <dl className="mt-10 grid grid-cols-[6rem_1fr] gap-y-3 text-[0.95rem]">
            <dt className="text-olive">Phone</dt>
            <dd>
              <a href="tel:+355690000000" className="hover:underline">+355 69 000 0000</a>
            </dd>
            <dt className="text-olive">WhatsApp</dt>
            <dd>
              <a href={whatsappLink("Hello Luxury Garden, I have a question.")} target="_blank" rel="noopener noreferrer" className="hover:underline">Message us</a>
            </dd>
            <dt className="text-olive">Email</dt>
            <dd>
              <a href="mailto:info@luxurygarden.al" className="hover:underline">info@luxurygarden.al</a>
            </dd>
            <dt className="text-olive">Nursery</dt>
            <dd>Open Monday to Saturday, 8:00 to 17:00</dd>
          </dl>

          <div className="arch relative mt-12 hidden aspect-[4/3] max-w-[24rem] bg-sage/50 lg:block">
            <Image
              src={images.contact}
              alt="Stone pool terrace edged with palm trees"
              fill
              sizes="28vw"
              className="object-cover"
            />
          </div>
        </div>

        <div className="lg:col-span-7">
          <ContactForm />
        </div>
      </div>
    </section>
  );
}
