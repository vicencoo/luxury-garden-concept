import Image from "next/image";
import { gardens } from "@/lib/content";

export default function Gardens() {
  const [feature, ...rest] = gardens;

  return (
    <section id="gardens" aria-labelledby="gardens-heading" className="scroll-mt-20">
      <div className="mx-auto max-w-[1320px] px-5 py-24 md:px-10 lg:py-32">
        <h2 id="gardens-heading" className="max-w-[44rem] font-display text-h2">
          The kind of gardens we build
        </h2>

        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-12 lg:gap-8">
          <figure className="md:col-span-2 lg:col-span-7 lg:row-span-2">
            <div className="relative aspect-[4/3] overflow-hidden rounded-sm bg-sage/40 lg:aspect-auto lg:h-full lg:min-h-[560px]">
              <Image
                src={feature.image}
                alt={feature.alt}
                fill
                sizes="(min-width: 1024px) 56vw, 100vw"
                className="object-cover"
              />
            </div>
            <figcaption className="mt-3 text-sm text-olive">{feature.title}</figcaption>
          </figure>

          {rest.map((garden, i) => (
            <figure
              key={garden.title}
              className={
                i === 2
                  ? "md:col-span-2 lg:col-span-5 lg:col-start-8 lg:row-start-3"
                  : "lg:col-span-5"
              }
            >
              <div className="relative aspect-[16/10] overflow-hidden rounded-sm bg-sage/40">
                <Image
                  src={garden.image}
                  alt={garden.alt}
                  fill
                  sizes="(min-width: 1024px) 40vw, (min-width: 768px) 50vw, 100vw"
                  className="object-cover"
                />
              </div>
              <figcaption className="mt-3 text-sm text-olive">{garden.title}</figcaption>
            </figure>
          ))}

          <div className="md:col-span-2 lg:col-span-6 lg:col-start-1 lg:row-start-3 lg:self-center">
            <p className="max-w-[32rem] text-lg leading-relaxed text-cypress/80">
              Clipped and formal, shaded by palms, or loose and green: we plan
              the planting around how you use the space and how much care you
              want to give it.
            </p>
            <a
              href="#contact"
              className="mt-6 inline-block font-medium underline decoration-olive/50 decoration-1 underline-offset-[6px] hover:decoration-cypress"
            >
              Book a site visit
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
