import Reveal from "./Reveal";
import { clients } from "@/lib/content";

export default function Clients() {
  return (
    <section aria-labelledby="klientet-titulli" className="bg-sand">
      <div className="mx-auto grid max-w-[1440px] gap-14 px-5 py-24 md:px-10 lg:grid-cols-12 lg:py-32">
        <Reveal className="lg:col-span-4">
          <p className="eyebrow flex items-center gap-4 text-stone">
            <span className="h-px w-10 bg-brass" />
            Për kë punojmë
          </p>
          <h2 id="klientet-titulli" className="mt-8 font-display text-[2.6rem] font-light leading-[1.05] md:text-5xl">
            Hapësira që <em className="text-moss">meritojnë</em> më të mirën.
          </h2>
        </Reveal>

        <ul className="grid gap-px overflow-hidden bg-forest/10 sm:grid-cols-2 lg:col-span-8">
          {clients.map((client, i) => (
            <Reveal as="li" key={client.title} delay={0.08 * i} className="bg-sand p-8 sm:p-10">
              <span className="font-display text-lg italic text-brass">0{i + 1}</span>
              <h3 className="mt-4 font-display text-[1.75rem] leading-tight">{client.title}</h3>
              <p className="mt-3 text-forest/65">{client.text}</p>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
