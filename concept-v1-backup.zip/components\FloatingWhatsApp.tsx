import { whatsappLink } from "@/lib/content";
import ChatIcon from "./ChatIcon";

/** Always-visible WhatsApp button on small screens. */
export default function FloatingWhatsApp() {
  return (
    <a
      href={whatsappLink("Hello Luxury Garden, I have a question.")}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Message Luxury Garden on WhatsApp"
      className="fixed bottom-5 right-5 z-50 inline-flex h-14 items-center gap-2 rounded-full bg-cypress px-5 font-medium text-chalk shadow-[0_8px_24px_rgba(29,42,33,0.35)] md:hidden"
    >
      <ChatIcon size={20} />
      WhatsApp
    </a>
  );
}
