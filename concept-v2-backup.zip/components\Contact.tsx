import Reveal from "./Reveal";
import ContactForm from "./ContactForm";
import { brand, whatsappLink } from "@/lib/content";

const channels = [
  { label: "WhatsApp", value: "Shkruani direkt", href: whatsappLink("Përshëndetje Luxury Garden, kam një pyetje.") },
  { label: "Instagram", value: brand.handle, href: brand.instagram },
  { label: "Serra", value: "Hapni në Google Maps", href: brand.maps },
];

export default function Contact() {
  return (
    <section id="kontakt" aria-labelledby="kontakt-titulli" className="grain scroll-mt-20 bg-forest text-ivory">
      <div className="mx-auto grid max-w-[1440px] gap-16 px-5 py-28 md:px-10 lg:grid-cols-12 lg:gap-10 lg:py-40">
        <Reveal className="lg:col-span-6">
          <p className="eyebrow flex items-center gap-4 text-brass">
            <span className="h-px w-10 bg-brass" />
            Kontakt
          </p>
          <h2 id="kontakt-titulli" className="mt-8 font-display text-h2 font-light">
            Le ta krijojmë
            <br />
            <em className="text-brass-soft">kopshtin tuaj.</em>
          </h2>
          <p className="mt-8 max-w-[28rem] text-ivory/65">
            Vijmë në pronën tuaj, dëgjojmë çfarë dëshironi dhe ju sjellim një
            propozim të qartë, me pemët, vazot dhe çmimin.
          </p>

          <a href={brand.phoneHref} className="mt-12 inline-block font-display text-4xl font-light transition-colors hover:text-brass-soft md:text-5xl">
            {brand.phone}
          </a>

          <ul className="mt-12 max-w-[30rem] border-t border-ivory/15">
            {channels.map((channel) => (
              <li key={channel.label} className="border-b border-ivory/15">
                <a
                  href={channel.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center justify-between py-5"
                >
                  <span className="eyebrow text-ivory/55">{channel.label}</span>
                  <span className="flex items-center gap-4 text-ivory/85 transition-colors group-hover:text-brass-soft">
                    {channel.value}
                    <span aria-hidden="true" className="transition-transform duration-500 group-hover:translate-x-1">
                      →
                    </span>
                  </span>
                </a>
              </li>
            ))}
          </ul>
        </Reveal>

        <Reveal className="lg:col-span-6 lg:self-end" delay={0.12}>
          <ContactForm />
        </Reveal>
      </div>
    </section>
  );
}
