import type { Metadata, Viewport } from "next";
import "@fontsource/marcellus/400.css";
import "@fontsource-variable/figtree/index.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "Luxury Garden | Decorative trees and garden design",
  description:
    "Luxury Garden designs and plants gardens for villas, hotels and residences, with mature olive, cypress, palm and citrus trees from our own nursery.",
};

export const viewport: Viewport = {
  themeColor: "#1d2a21",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en">
      <body className="min-h-full">{children}</body>
    </html>
  );
}
