import Logo from "./Logo";
import { navLinks } from "@/lib/content";

export default function Footer() {
  return (
    <footer className="bg-cypress text-chalk">
      <div className="mx-auto max-w-[1320px] px-5 py-16 md:px-10">
        <div className="flex flex-col gap-10 md:flex-row md:items-start md:justify-between">
          <div className="max-w-[22rem]">
            <Logo />
            <p className="mt-5 text-chalk/70">
              Decorative trees, garden design and garden care for villas,
              hotels and residences.
            </p>
          </div>
          <nav aria-label="Footer">
            <ul className="grid grid-cols-2 gap-x-12 gap-y-3 text-chalk/80">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="hover:text-chalk">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>
        <p className="mt-14 border-t border-sage/25 pt-6 text-sm text-chalk/55">
          © 2026 Luxury Garden. Concept design.
        </p>
      </div>
    </footer>
  );
}
