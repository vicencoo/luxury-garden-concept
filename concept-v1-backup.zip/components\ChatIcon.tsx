/** Speech bubble with a handset, used on WhatsApp buttons. */
export default function ChatIcon({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M12 2.75a9.25 9.25 0 0 0-7.98 13.93L3 21l4.45-1a9.25 9.25 0 1 0 4.55-17.25Z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path
        d="M8.9 7.6c.25-.3.62-.3.82 0l.95 1.6c.15.27.1.6-.12.82l-.55.55c.5 1.15 1.4 2.08 2.6 2.62l.55-.55a.68.68 0 0 1 .82-.12l1.6.95c.3.2.3.57 0 .82l-.8.75c-.45.42-1.12.52-1.68.25a9.1 9.1 0 0 1-4.2-4.2c-.27-.56-.17-1.23.25-1.68l.76-.8Z"
        fill="currentColor"
      />
    </svg>
  );
}
