import { marquee } from "@/lib/content";

function Row({ hidden = false }: { hidden?: boolean }) {
  return (
    <ul className="flex shrink-0 items-center" aria-hidden={hidden || undefined}>
      {marquee.map((word) => (
        <li key={word} className="flex items-center whitespace-nowrap">
          <span className="px-8 font-display text-3xl font-light italic md:px-12 md:text-4xl">{word}</span>
          <span className="text-xs text-brass">✦</span>
        </li>
      ))}
    </ul>
  );
}

/** Slow ribbon of what we grow and do, between the hero and the page. */
export default function Marquee() {
  return (
    <div className="overflow-hidden border-y border-ivory/10 bg-pine py-7 text-ivory/85">
      <div className="marquee flex w-max">
        <Row />
        <Row hidden />
      </div>
    </div>
  );
}
