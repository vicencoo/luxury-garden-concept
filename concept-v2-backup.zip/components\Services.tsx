"use client";

import { useState } from "react";
import Image from "next/image";
import Reveal from "./Reveal";
import { services } from "@/lib/content";

export default function Services() {
  const [active, setActive] = useState(0);

  return (
    <section id="sherbimet" aria-labelledby="sherbimet-titulli" className="scroll-mt-20 bg-sand">
      <div className="mx-auto max-w-[1440px] px-5 py-28 md:px-10 lg:py-40">
        <div className="grid gap-8 md:grid-cols-12 md:items-end">
          <Reveal className="md:col-span-7">
            <p className="eyebrow flex items-center gap-4 text-stone">
              <span className="h-px w-10 bg-brass" />
              Shërbimet
            </p>
            <h2 id="sherbimet-titulli" className="mt-8 font-display text-h2 font-light">
              Nga ideja e parë <br className="hidden sm:block" />
              <em className="text-moss">te kopshti i rritur.</em>
            </h2>
          </Reveal>
          <Reveal className="md:col-span-4 md:col-start-9" delay={0.1}>
            <p className="text-forest/70">
              Një ekip i vetëm për gjithçka: projektin, pemët, transportin,
              mbjelljen dhe kujdesin e përditshëm që e mban kopshtin të bukur.
            </p>
          </Reveal>
        </div>

        <div className="mt-20 grid gap-12 lg:grid-cols-12">
          <ol className="lg:col-span-7">
            {services.map((service, i) => {
              const isActive = active === i;
              return (
                <li
                  key={service.title}
                  onMouseEnter={() => setActive(i)}
                  onFocus={() => setActive(i)}
                  tabIndex={0}
                  className="group cursor-default border-t border-forest/15 py-10 outline-none last:border-b"
                >
                  <div className="flex items-baseline gap-6 md:gap-10">
                    <span
                      className={`font-display text-xl italic transition-colors duration-500 ${
                        isActive ? "text-brass" : "text-stone"
                      }`}
                    >
                      0{i + 1}
                    </span>
                    <div className="flex-1">
                      <h3
                        className={`font-display text-h3 transition-all duration-700 ease-luxe lg:text-[2.6rem] ${
                          isActive ? "lg:translate-x-3" : "text-forest/55"
                        }`}
                      >
                        {service.title}
                      </h3>
                      <div
                        className={`grid transition-[grid-template-rows,opacity] duration-700 ease-luxe lg:grid-rows-[0fr] lg:opacity-0 ${
                          isActive ? "lg:grid-rows-[1fr] lg:opacity-100" : ""
                        }`}
                      >
                        <div className="overflow-hidden">
                          <div className="relative mt-6 aspect-[4/3] w-full max-w-[26rem] overflow-hidden lg:hidden">
                            <Image
                              src={service.photo.src}
                              alt={service.photo.alt}
                              fill
                              sizes="(min-width: 640px) 352px, 80vw"
                              className="object-cover"
                            />
                          </div>
                          <p className="mt-5 max-w-[34rem] text-forest/70 lg:translate-x-3">{service.text}</p>
                          <ul className="mt-6 flex flex-wrap gap-2 lg:translate-x-3">
                            {service.points.map((point) => (
                              <li
                                key={point}
                                className="rounded-full border border-forest/15 px-4 py-1.5 text-sm text-forest/75"
                              >
                                {point}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                </li>
              );
            })}
          </ol>

          <div className="hidden lg:col-span-4 lg:col-start-9 lg:block">
            <div className="sticky top-28">
              <div className="arch relative aspect-[9/14] w-full bg-forest/10">
                {services.map((service, i) => (
                  <Image
                    key={service.title}
                    src={service.photo.src}
                    alt={active === i ? service.photo.alt : ""}
                    fill
                    sizes="400px"
                    className={`object-cover transition-[opacity,transform] duration-[1200ms] ease-luxe ${
                      active === i ? "scale-100 opacity-100" : "scale-105 opacity-0"
                    }`}
                  />
                ))}
              </div>
              <p className="mt-5 flex items-center justify-between text-sm text-stone">
                <span className="eyebrow">{services[active].title}</span>
                <span className="font-display text-lg italic">
                  0{active + 1} / 0{services.length}
                </span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
