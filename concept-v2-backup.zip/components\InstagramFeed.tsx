import Image from "next/image";
import Reveal from "./Reveal";
import { brand, instagramFeed } from "@/lib/content";

function InstagramIcon({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" aria-hidden="true" className={className}>
      <rect x="3" y="3" width="18" height="18" rx="5" />
      <circle cx="12" cy="12" r="4.2" />
      <circle cx="17.3" cy="6.7" r="0.6" fill="currentColor" />
    </svg>
  );
}

export default function InstagramFeed() {
  return (
    <section aria-labelledby="instagram-titulli" className="bg-ivory">
      <div className="mx-auto max-w-[1440px] px-5 py-28 md:px-10 lg:py-36">
        <Reveal className="flex flex-col items-center text-center">
          <p className="eyebrow text-stone">Na ndiqni në Instagram</p>
          <h2 id="instagram-titulli" className="mt-6 font-display text-h2 font-light">
            <a href={brand.instagram} target="_blank" rel="noopener noreferrer" className="transition-colors hover:text-moss">
              {brand.handle}
            </a>
          </h2>
          <p className="mt-4 text-forest/65">
            <span className="font-display text-xl italic text-brass">{brand.followers}</span> ndjekës shohin
            punën tonë çdo ditë.
          </p>
        </Reveal>

        <ul className="mt-16 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {instagramFeed.map((photo, i) => (
            <Reveal as="li" key={photo.src} delay={0.06 * i}>
              <a
                href={brand.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative block aspect-[9/16] overflow-hidden bg-sand"
              >
                <Image
                  src={photo.src}
                  alt={photo.alt}
                  fill
                  sizes="(min-width: 1024px) 16vw, (min-width: 640px) 32vw, 48vw"
                  className="object-cover transition-transform duration-[1400ms] ease-luxe group-hover:scale-105"
                />
                <span className="absolute inset-0 grid place-items-center bg-forest/0 text-ivory opacity-0 transition-all duration-500 group-hover:bg-forest/45 group-hover:opacity-100">
                  <InstagramIcon className="h-8 w-8" />
                </span>
              </a>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
