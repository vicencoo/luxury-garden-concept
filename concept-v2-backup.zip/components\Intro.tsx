import Image from "next/image";
import Reveal from "./Reveal";
import { photos } from "@/lib/content";

type Photo = { src: string; alt: string };

/** A small photo set into the line of text, like a pressed leaf. */
function Pill({ photo }: { photo: Photo }) {
  return (
    <span className="relative mx-1 inline-block h-[0.78em] w-[1.9em] translate-y-[0.06em] overflow-hidden rounded-full align-baseline">
      <Image src={photo.src} alt="" fill sizes="120px" className="object-cover" />
    </span>
  );
}

export default function Intro() {
  return (
    <section className="bg-ivory">
      <div className="mx-auto max-w-[1440px] px-5 py-28 md:px-10 lg:py-40">
        <Reveal>
          <p className="eyebrow flex items-center gap-4 text-stone">
            <span className="h-px w-10 bg-brass" />
            Filozofia jonë
          </p>
        </Reveal>

        <Reveal delay={0.1}>
          <p className="mt-10 max-w-[68rem] font-display text-lede font-light">
            Çdo kopsht fillon me një pemë <Pill photo={photos.oliveField} /> të zgjedhur me dorë,
            një vazo <Pill photo={photos.nursery} /> që i përket hapësirës dhe një ekip{" "}
            <Pill photo={photos.rooftopCrane} /> që kujdeset për të,{" "}
            <em className="text-moss">stinë pas stine.</em>
          </p>
        </Reveal>

        <div className="mt-16 grid gap-10 border-t border-forest/10 pt-10 md:grid-cols-12">
          <Reveal className="md:col-span-4">
            <p className="font-display text-2xl italic text-moss">Asgjë e rastësishme.</p>
          </Reveal>
          <Reveal className="md:col-span-6 md:col-start-7" delay={0.1}>
            <p className="text-lg leading-relaxed text-forest/70">
              Nga serra jonë dalin pemë dekorative të të gjitha llojeve, lule
              natyrale dhe vazo për çdo ambient. Nga ekipi ynë dalin kopshte të
              projektuara, të mbjella dhe të mirëmbajtura me të njëjtin standard,
              për ata që duan që hapësira e tyre e gjelbër të flasë për ta.
            </p>
            <a href="#sherbimet" className="eyebrow group mt-8 inline-flex items-center gap-3 text-forest">
              Si punojmë
              <span className="h-px w-8 bg-brass transition-all duration-500 group-hover:w-14" />
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
