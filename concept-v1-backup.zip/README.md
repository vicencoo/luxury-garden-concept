# Luxury Garden — website concept

Home page concept for Luxury Garden: decorative trees, garden design and garden
care for villas, hotels and residences. Built with Next.js (App Router),
TypeScript and Tailwind CSS.

## Run it

```bash
npm install
npm run dev
```

Then open http://localhost:3000.

## Where things live

- `app/page.tsx` — the home page, assembled from sections
- `components/` — one file per section (Header, Hero, CategoryStrip, Shop, Offer, Clients, Services, Gardens, Process, Contact, Footer, FloatingWhatsApp)
- `lib/content.ts` — all copy, products, prices, the seasonal offer, the WhatsApp number and photo links in one place
- `app/globals.css` — colour tokens, type scale and the arch shape

## Notes

- Photos are Unsplash placeholders. Replace the links in `lib/content.ts`
  (or put your own photos in `public/` and point to them).
- Phone, email and the WhatsApp number (`whatsappNumber` in `lib/content.ts`) are placeholders.
- Product prices are examples. Set a product's `price` to `null` to show "Price on request".
- To add a product, copy one entry in the `products` list and change it. The filter counts update by themselves.
- To change the seasonal offer, edit `offer` in `lib/content.ts`.
- The contact form shows a confirmation but does not send anything yet.
