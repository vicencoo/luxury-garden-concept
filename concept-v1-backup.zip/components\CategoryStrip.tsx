"use client";

import Image from "next/image";
import { categories } from "@/lib/content";
import { selectShopFilter } from "@/lib/shop-filter";

export default function CategoryStrip() {
  return (
    <nav aria-label="Shop by category" className="mx-auto max-w-[1320px] px-5 pb-20 md:px-10 lg:pb-28">
      <ul className="grid gap-4 border-t border-cypress/15 pt-8 md:grid-cols-3 md:gap-8">
        {categories.map((category) => (
          <li key={category.id}>
            <a
              href="#shop"
              onClick={() => selectShopFilter(category.id)}
              className="group flex items-center gap-5 rounded-lg p-2 -m-2 transition-colors hover:bg-chalk/70"
            >
              <span className="arch relative h-28 w-22 shrink-0 bg-sage/40">
                <Image
                  src={category.image}
                  alt=""
                  fill
                  sizes="88px"
                  className="object-cover"
                />
              </span>
              <span>
                <span className="block font-display text-h3">{category.label}</span>
                <span className="mt-1 block text-[0.95rem] leading-snug text-cypress/70">
                  {category.text}
                </span>
                <span className="mt-2 inline-block text-[0.95rem] font-medium underline decoration-olive/50 underline-offset-4 group-hover:decoration-cypress">
                  Shop {category.label.toLowerCase()}
                </span>
              </span>
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}
