import Image from "next/image";
import { TreeMark } from "./Logo";
import { brand, heroFacts, photos } from "@/lib/content";

function SealBadge() {
  return (
    <div className="relative grid h-32 w-32 place-items-center rounded-full bg-forest text-brass-soft shadow-[0_20px_50px_rgba(0,0,0,0.35)] md:h-36 md:w-36">
      <svg viewBox="0 0 120 120" className="spin-slow absolute inset-0 h-full w-full" aria-hidden="true">
        <defs>
          <path id="seal-circle" d="M60 60m-46 0a46 46 0 1 1 92 0a46 46 0 1 1 -92 0" />
        </defs>
        <text fill="currentColor" style={{ fontSize: "9.4px", letterSpacing: "0.32em" }}>
          <textPath href="#seal-circle">PROJEKTIM · ZBATIM · MIRËMBAJTJE ·</textPath>
        </text>
      </svg>
      <TreeMark className="h-9 w-10 text-ivory" />
    </div>
  );
}

export default function Hero() {
  return (
    <section id="top" className="grain relative overflow-hidden bg-forest text-ivory">
      {/* soft light behind the photograph, like a garden lamp */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-40 top-10 -z-10 h-[46rem] w-[46rem] rounded-full bg-[radial-gradient(circle,rgba(196,163,106,0.16),transparent_62%)]"
      />

      <div className="mx-auto grid min-h-[100svh] max-w-[1440px] grid-cols-1 gap-16 px-5 pb-10 pt-32 md:px-10 lg:grid-cols-12 lg:gap-8 lg:pt-36">
        <div className="flex flex-col justify-center lg:col-span-7">
          <p className="settle eyebrow flex items-center gap-4 text-brass">
            <span className="h-px w-10 bg-brass" />
            Kopshte · Pemë dekorative · Vazo
          </p>

          <h1 className="mt-8 font-display text-display font-light">
            <span className="settle block" style={{ animationDelay: "0.1s" }}>
              Natyra,
            </span>
            <span className="settle block italic text-brass-soft" style={{ animationDelay: "0.22s" }}>
              e kuruar
            </span>
            <span className="settle block" style={{ animationDelay: "0.34s" }}>
              si vepër arti.
            </span>
          </h1>

          <p
            className="settle mt-10 max-w-[33rem] text-lg leading-relaxed text-ivory/70"
            style={{ animationDelay: "0.5s" }}
          >
            Projektojmë, mbjellim dhe mirëmbajmë kopshte për vila, hotele dhe
            rezidenca, me ullinj shekullorë, palma dhe vazo të zgjedhura një nga
            një.
          </p>

          <div className="settle mt-12 flex flex-wrap items-center gap-x-10 gap-y-5" style={{ animationDelay: "0.62s" }}>
            <a
              href="#kontakt"
              className="eyebrow bg-brass px-8 py-5 text-forest transition-colors duration-500 hover:bg-ivory"
            >
              Rezervo një vizitë
            </a>
            <a href="#sherbimet" className="eyebrow group inline-flex items-center gap-3 text-ivory/85 hover:text-ivory">
              Zbuloni shërbimet
              <span className="h-px w-8 bg-brass transition-all duration-500 group-hover:w-14" />
            </a>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-[26rem] self-center lg:col-span-5 lg:mr-0">
          <div className="arch rise relative aspect-[9/14] w-full bg-pine">
            <Image
              src={photos.oliveNight.src}
              alt={photos.oliveNight.alt}
              fill
              priority
              sizes="(min-width: 1024px) 420px, 88vw"
              className="slow-zoom object-cover"
            />
          </div>
          <div
            className="arch rise absolute -bottom-6 -left-6 aspect-[3/4] w-[38%] border-[6px] border-b-0 border-forest bg-pine sm:-left-14"
            style={{ animationDelay: "0.4s" }}
          >
            <Image src={photos.whiteVases.src} alt={photos.whiteVases.alt} fill sizes="180px" className="object-cover" />
          </div>
          <div className="settle absolute -right-2 top-8 sm:-right-8 xl:-right-12" style={{ animationDelay: "0.9s" }}>
            <SealBadge />
          </div>
        </div>

        <div className="settle lg:col-span-12" style={{ animationDelay: "0.8s" }}>
          <ul className="flex flex-col gap-4 border-t border-ivory/15 pt-7 text-sm text-ivory/60 md:flex-row md:items-center md:justify-between">
            {heroFacts.map((fact, i) => (
              <li key={fact} className="flex items-center gap-4">
                <span className="font-display text-base italic text-brass">0{i + 1}</span>
                {fact}
              </li>
            ))}
            <li>
              <a
                href={brand.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 transition-colors hover:text-ivory"
              >
                <span className="font-display text-base italic text-brass">{brand.followers}</span>
                ndjekës në Instagram
              </a>
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
