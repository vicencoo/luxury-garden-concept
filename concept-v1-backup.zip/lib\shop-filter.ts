import type { Category } from "./content";

// Lets the category links near the top of the page pre-select a filter in the shop.
export const SHOP_FILTER_EVENT = "luxurygarden:shop-filter";

export type ShopFilter = Category | "all";

export function selectShopFilter(filter: ShopFilter) {
  window.dispatchEvent(new CustomEvent<ShopFilter>(SHOP_FILTER_EVENT, { detail: filter }));
}
