type LogoProps = {
  className?: string;
};

/** Wordmark: a cypress standing inside a hedge arch. */
export default function Logo({ className = "" }: LogoProps) {
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <svg
        width="26"
        height="32"
        viewBox="0 0 26 32"
        fill="none"
        aria-hidden="true"
        className="shrink-0"
      >
        <path
          d="M1.5 31V13a11.5 11.5 0 0 1 23 0v18"
          stroke="currentColor"
          strokeWidth="1.5"
        />
        <path
          d="M13 27c-3.6-5-3.4-13.4 0-19 3.4 5.6 3.6 14 0 19Z"
          fill="currentColor"
        />
        <path d="M13 27v4" stroke="currentColor" strokeWidth="1.5" />
      </svg>
      <span className="font-display text-[1.35rem] leading-none tracking-[0.02em]">
        Luxury Garden
      </span>
    </span>
  );
}
