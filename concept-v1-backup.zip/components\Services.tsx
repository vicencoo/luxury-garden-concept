import Image from "next/image";
import { images, services } from "@/lib/content";

export default function Services() {
  return (
    <section
      id="services"
      aria-labelledby="services-heading"
      className="scroll-mt-20 bg-cypress text-chalk"
    >
      <div className="mx-auto grid max-w-[1320px] gap-16 px-5 py-24 md:px-10 lg:grid-cols-12 lg:gap-10 lg:py-32">
        <div className="lg:col-span-5">
          <h2 id="services-heading" className="font-display text-h2">
            Design, planting and care
          </h2>
          <p className="mt-6 max-w-[30rem] text-chalk/75">
            Take one service or all three. Gardens we plant and then maintain
            ourselves are the ones that age best.
          </p>
          <div className="arch relative mt-12 hidden aspect-[4/5] max-w-[26rem] bg-cypress-soft lg:block">
            <Image
              src={images.design}
              alt="Formal garden with a fountain and clipped hedges"
              fill
              sizes="30vw"
              className="object-cover"
            />
          </div>
        </div>

        <div className="lg:col-span-6 lg:col-start-7">
          <ul>
            {services.map((service) => (
              <li
                key={service.title}
                className="border-t border-sage/30 py-10 first:pt-0 first:border-t-0 lg:first:pt-2"
              >
                <h3 className="font-display text-h3">{service.title}</h3>
                <p className="mt-4 max-w-[34rem] text-chalk/75">{service.text}</p>
                <ul className="mt-6 flex flex-wrap gap-2">
                  {service.points.map((point) => (
                    <li
                      key={point}
                      className="rounded-full border border-sage/35 px-4 py-1.5 text-sm text-chalk/90"
                    >
                      {point}
                    </li>
                  ))}
                </ul>
              </li>
            ))}
          </ul>

          <div className="mt-6 flex flex-col gap-8 border-t border-sage/30 pt-10 sm:flex-row sm:items-center">
            <div className="arch relative aspect-square w-28 shrink-0 bg-cypress-soft">
              <Image
                src={images.care}
                alt="Hands pressing fresh turf into soil"
                fill
                sizes="112px"
                className="object-cover"
              />
            </div>
            <div>
              <p className="max-w-[26rem] text-chalk/80">
                Not sure which you need? We start every project with a site
                visit and tell you honestly what the garden needs.
              </p>
              <a
                href="#contact"
                className="mt-5 inline-block rounded-full bg-citrus px-6 py-3 font-medium text-cypress transition-colors hover:bg-[#e3c45e]"
              >
                Book a site visit
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
