import Image from "next/image";
import { offer, whatsappLink } from "@/lib/content";
import ChatIcon from "./ChatIcon";

export default function Offer() {
  return (
    <section id="offer" aria-labelledby="offer-heading" className="scroll-mt-20">
      <div className="mx-auto grid max-w-[1320px] items-center gap-12 px-5 py-24 md:px-10 lg:grid-cols-12 lg:gap-10 lg:py-32">
        <div className="arch relative mx-auto aspect-[4/5] w-full max-w-[30rem] bg-sage/40 lg:col-span-5">
          <Image
            src={offer.image}
            alt={offer.alt}
            fill
            sizes="(min-width: 1024px) 36vw, 90vw"
            className="object-cover"
          />
        </div>

        <div className="lg:col-span-6 lg:col-start-7">
          <p className="inline-block rounded-full bg-citrus px-3.5 py-1 text-sm font-medium text-cypress">
            {offer.label}
          </p>
          <h2 id="offer-heading" className="mt-6 font-display text-h2">
            {offer.title}
          </h2>
          <p className="mt-6 max-w-[34rem] text-cypress/80">{offer.text}</p>

          <ul className="mt-8 max-w-[30rem] border-t border-cypress/15">
            {offer.includes.map((item) => (
              <li key={item} className="flex items-center gap-3 border-b border-cypress/15 py-3">
                <svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true" className="shrink-0 text-olive">
                  <path d="M2 7.5l3 3 7-7" stroke="currentColor" strokeWidth="1.6" fill="none" />
                </svg>
                {item}
              </li>
            ))}
          </ul>

          <p className="mt-8 font-display text-h3">{offer.price}</p>

          <div className="mt-8 flex flex-wrap items-center gap-x-8 gap-y-4">
            <a
              href={whatsappLink(`Hello Luxury Garden, I'm interested in the ${offer.label.toLowerCase()}: ${offer.title}`)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 rounded-full bg-cypress px-7 py-4 font-medium text-chalk transition-colors hover:bg-cypress-soft"
            >
              <ChatIcon />
              Reserve on WhatsApp
            </a>
            <a
              href="#shop"
              className="font-medium underline decoration-olive/50 decoration-1 underline-offset-[6px] hover:decoration-cypress"
            >
              See all products
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
