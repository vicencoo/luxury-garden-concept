"use client";

import { useState, type FormEvent } from "react";
import { interests } from "@/lib/content";

const field =
  "mt-3 w-full font-normal normal-case tracking-normal border-0 border-b border-ivory/25 bg-transparent px-0 py-3 text-lg text-ivory placeholder:text-ivory/35 transition-colors focus:border-brass focus:outline-none focus-visible:outline-none";
const label = "eyebrow block text-ivory/55";

export default function ContactForm() {
  const [sentTo, setSentTo] = useState<string | null>(null);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    // Concept only: connect this to email or a CRM before going live.
    setSentTo(String(data.get("name") || "").split(" ")[0] || "");
  }

  if (sentTo !== null) {
    return (
      <div role="status" className="flex h-full flex-col justify-center border border-ivory/15 p-8 md:p-12">
        <p className="font-display text-h3">
          Faleminderit{sentTo ? `, ${sentTo}` : ""}. <em className="text-brass-soft">Kërkesa u dërgua.</em>
        </p>
        <p className="mt-5 max-w-[30rem] text-ivory/65">
          Do t&apos;ju kontaktojmë së shpejti për të caktuar një vizitë ose për
          t&apos;ju dërguar çmimet.
        </p>
        <button
          type="button"
          onClick={() => setSentTo(null)}
          className="eyebrow mt-10 self-start border-b border-brass pb-1 text-brass-soft"
        >
          Dërgo një kërkesë tjetër
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="border border-ivory/15 p-6 sm:p-10">
      <div className="grid gap-9 sm:grid-cols-2">
        <label className={label}>
          Emri
          <input name="name" required autoComplete="name" placeholder="Emri dhe mbiemri" className={field} />
        </label>
        <label className={label}>
          Telefoni
          <input name="phone" type="tel" required autoComplete="tel" placeholder="+355" className={field} />
        </label>
        <label className={`${label} sm:col-span-2`}>
          Më intereson
          <select name="interest" defaultValue={interests[0]} className={`${field} [&>option]:text-forest`}>
            {interests.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>
        </label>
        <label className={`${label} sm:col-span-2`}>
          Mesazhi
          <textarea
            name="message"
            rows={3}
            placeholder="Na tregoni për hapësirën tuaj"
            className={`${field} resize-y`}
          />
        </label>
      </div>
      <button
        type="submit"
        className="eyebrow mt-12 w-full bg-brass px-8 py-5 text-forest transition-colors duration-500 hover:bg-ivory sm:w-auto"
      >
        Dërgo kërkesën
      </button>
    </form>
  );
}
