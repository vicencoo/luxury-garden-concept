import Logo from "./Logo";
import { brand, navLinks } from "@/lib/content";

export default function Footer() {
  return (
    <footer className="border-t border-ivory/10 bg-forest text-ivory">
      <div className="mx-auto max-w-[1440px] px-5 pb-28 pt-20 md:px-10 md:pb-12">
        <div className="flex flex-col gap-12 md:flex-row md:items-start md:justify-between">
          <div className="max-w-[22rem]">
            <Logo />
            <p className="mt-6 text-ivory/55">
              Lule natyrale, pemë dekorative të të gjitha llojeve, projekte dhe
              zbatim të zonave të gjelbra.
            </p>
          </div>
          <nav aria-label="Fundi i faqes">
            <ul className="grid grid-cols-2 gap-x-14 gap-y-4">
              {navLinks.map((link) => (
                <li key={link.href}>
                  <a href={link.href} className="eyebrow text-ivory/60 transition-colors hover:text-ivory">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          <div className="flex flex-col gap-3">
            <a href={brand.phoneHref} className="font-display text-2xl transition-colors hover:text-brass-soft">
              {brand.phone}
            </a>
            <a
              href={brand.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="text-ivory/60 transition-colors hover:text-ivory"
            >
              {brand.handle}
            </a>
          </div>
        </div>

        <p aria-hidden="true" className="mt-20 select-none text-center font-display text-[17vw] font-light leading-none tracking-[-0.02em] text-ivory/[0.06] md:text-[12.5vw]">
          Luxury Garden
        </p>

        <div className="mt-8 flex flex-col gap-2 border-t border-ivory/10 pt-6 text-sm text-ivory/45 md:flex-row md:justify-between">
          <p>© 2026 Luxury Garden. Të gjitha të drejtat e rezervuara.</p>
          <p>Koncept dizajni</p>
        </div>
      </div>
    </footer>
  );
}
