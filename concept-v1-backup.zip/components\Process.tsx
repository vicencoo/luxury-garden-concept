import { steps } from "@/lib/content";

export default function Process() {
  return (
    <section
      id="process"
      aria-labelledby="process-heading"
      className="scroll-mt-20 border-t border-cypress/10"
    >
      <div className="mx-auto max-w-[1320px] px-5 py-24 md:px-10 lg:py-32">
        <div className="grid gap-6 lg:grid-cols-12">
          <h2 id="process-heading" className="font-display text-h2 lg:col-span-5">
            From first visit to first season
          </h2>
          <p className="max-w-[34rem] text-cypress/80 lg:col-span-5 lg:col-start-8 lg:pt-3">
            Most gardens take four to ten weeks from the site visit to the last
            tree planted, depending on size and the season.
          </p>
        </div>

        <ol className="mt-16 grid gap-12 sm:grid-cols-2 lg:grid-cols-4 lg:gap-10">
          {steps.map((step, i) => (
            <li key={step.title} className="border-t border-cypress/25 pt-6">
              <span className="font-display text-5xl text-olive" aria-hidden="true">
                {i + 1}
              </span>
              <h3 className="mt-5 font-display text-h3">{step.title}</h3>
              <p className="mt-3 text-cypress/75">{step.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
