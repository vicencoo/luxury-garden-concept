import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import Intro from "@/components/Intro";
import Services from "@/components/Services";
import OliveStory from "@/components/OliveStory";
import Collection from "@/components/Collection";
import Clients from "@/components/Clients";
import InstagramFeed from "@/components/InstagramFeed";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import FloatingWhatsApp from "@/components/FloatingWhatsApp";

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Marquee />
        <Intro />
        <Services />
        <OliveStory />
        <Collection />
        <Clients />
        <InstagramFeed />
        <Contact />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </>
  );
}
