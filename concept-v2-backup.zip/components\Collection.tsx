import Image from "next/image";
import Reveal from "./Reveal";
import { TreeMark } from "./Logo";
import { brand, collection, whatsappLink } from "@/lib/content";

export default function Collection() {
  return (
    <section id="koleksioni" aria-labelledby="koleksioni-titulli" className="scroll-mt-20 bg-ivory">
      <div className="mx-auto max-w-[1440px] px-5 py-28 md:px-10 lg:py-40">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <Reveal>
            <p className="eyebrow flex items-center gap-4 text-stone">
              <span className="h-px w-10 bg-brass" />
              Koleksioni në serrë
            </p>
            <h2 id="koleksioni-titulli" className="mt-8 font-display text-h2 font-light">
              Zgjidhni vetë, <em className="text-moss">një nga një.</em>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="max-w-[24rem] text-forest/70">
              Vizitoni serrën tonë dhe zgjidhni pemën, bimën ose vazon e saktë që
              dëshironi. Shesim me pakicë dhe me shumicë.
            </p>
          </Reveal>
        </div>

        <ul className="mt-20 grid gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-4">
          {collection.map((item, i) => (
            <Reveal as="li" key={item.title} delay={0.1 * i} className={i % 2 === 1 ? "lg:mt-20" : ""}>
              <div className="group">
                <div className="arch relative aspect-[9/14] bg-sand">
                  <Image
                    src={item.photo.src}
                    alt={item.photo.alt}
                    fill
                    sizes="(min-width: 1024px) 23vw, (min-width: 640px) 45vw, 90vw"
                    className="object-cover transition-transform duration-[1600ms] ease-luxe group-hover:scale-105"
                  />
                </div>
                <h3 className="mt-7 font-display text-[1.85rem] leading-tight">{item.title}</h3>
                <p className="mt-2 text-forest/65">{item.text}</p>
              </div>
            </Reveal>
          ))}

          <Reveal as="li" delay={0.3} className="lg:mt-20">
            <div className="grain arch flex aspect-[9/14] flex-col items-center justify-center bg-forest px-8 text-center text-ivory">
              <TreeMark className="h-10 w-12 text-brass" />
              <h3 className="mt-8 font-display text-[1.85rem] leading-tight">Lule natyrale</h3>
              <p className="mt-3 text-ivory/65">
                Buqeta dhe kompozime me porosi, për shtëpi, hotele dhe evente.
              </p>
              <a
                href={whatsappLink("Përshëndetje Luxury Garden, dua të porosis lule.")}
                target="_blank"
                rel="noopener noreferrer"
                className="eyebrow mt-8 border-b border-brass pb-1 text-brass-soft transition-colors hover:text-ivory"
              >
                Porosit në WhatsApp
              </a>
            </div>
          </Reveal>
        </ul>

        <Reveal className="mt-24 flex flex-col items-start gap-6 border-t border-forest/10 pt-10 md:flex-row md:items-center md:justify-between">
          <p className="font-display text-2xl italic text-moss md:text-3xl">
            Pika juaj e shumicës për çdo ambient të gjelbër.
          </p>
          <a
            href={brand.maps}
            target="_blank"
            rel="noopener noreferrer"
            className="eyebrow bg-forest px-8 py-5 text-ivory transition-colors duration-500 hover:bg-moss"
          >
            Vizitoni serrën
          </a>
        </Reveal>
      </div>
    </section>
  );
}
