import Image from "next/image";
import Reveal from "./Reveal";
import { oliveSteps } from "@/lib/content";

const offsets = ["md:mt-0", "md:mt-28", "md:mt-56"];

export default function OliveStory() {
  return (
    <section id="ullinjte" aria-labelledby="ullinjte-titulli" className="grain scroll-mt-20 overflow-hidden bg-forest text-ivory">
      <div className="mx-auto max-w-[1440px] px-5 py-28 md:px-10 lg:py-40">
        <div className="grid gap-10 md:grid-cols-12">
          <Reveal className="md:col-span-8">
            <p className="eyebrow flex items-center gap-4 text-brass">
              <span className="h-px w-10 bg-brass" />
              Nga toka, në oborrin tuaj
            </p>
            <h2 id="ullinjte-titulli" className="mt-8 font-display text-h2 font-light">
              Ullinj me shekuj histori,
              <br />
              <em className="text-brass-soft">të zhvendosur me kujdes.</em>
            </h2>
          </Reveal>
          <Reveal className="md:col-span-4 md:self-end" delay={0.1}>
            <p className="text-ivory/65">
              Një ulli shekullor është zemra e çdo kopshti mesdhetar. Ne e
              gjejmë, e zhvendosim dhe e mbjellim, që të vazhdojë të rritet për
              breza të tjerë.
            </p>
          </Reveal>
        </div>

        <ol className="mt-24 grid gap-20 md:grid-cols-3 md:gap-10 lg:gap-16">
          {oliveSteps.map((step, i) => (
            <Reveal as="li" key={step.title} className={offsets[i]} delay={0.12 * i}>
              <div className="relative">
                <div aria-hidden="true" className="absolute inset-0 translate-x-3 translate-y-3 border border-brass/40" />
                <div className="relative aspect-[9/14] overflow-hidden bg-pine">
                  <Image
                    src={step.photo.src}
                    alt={step.photo.alt}
                    fill
                    sizes="(min-width: 768px) 30vw, 90vw"
                    className="object-cover transition-transform duration-[1600ms] ease-luxe hover:scale-105"
                  />
                </div>
              </div>
              <div className="mt-10 flex items-baseline gap-5">
                <span className="font-display text-4xl font-light italic text-brass">{step.numeral}</span>
                <h3 className="font-display text-h3">{step.title}</h3>
              </div>
              <p className="mt-4 max-w-[24rem] text-ivory/65">{step.text}</p>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}
