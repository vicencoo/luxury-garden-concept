// All page copy and photography in one place, so the concept is easy to edit.
// Photos are placeholders from Unsplash; replace with Luxury Garden project photos.

const unsplash = (id: string) => `https://images.unsplash.com/photo-${id}`;

export const images = {
  hero: unsplash("1789593847377-a0452ab3f3c9"),
  heroDetail: unsplash("1751972788348-3360f69603f6"),
  villas: unsplash("1783103085124-fd887a61dba9"),
  hotels: unsplash("1636484807510-bc2ffbaf3241"),
  residences: unsplash("1667687721690-1afc7da46f25"),
  design: unsplash("1759765098541-48769ba99219"),
  care: unsplash("1734079692079-aae7e24a7035"),
  contact: unsplash("1780287857653-124e013bdd7c"),
};

// WhatsApp number in international format, digits only (placeholder).
export const whatsappNumber = "355690000000";

export function whatsappLink(message: string) {
  return `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export const navLinks = [
  { href: "#shop", label: "Shop" },
  { href: "#offer", label: "Offers" },
  { href: "#services", label: "Garden design" },
  { href: "#gardens", label: "Gardens" },
  { href: "#process", label: "How we work" },
  { href: "#contact", label: "Contact" },
];

export const clients = [
  {
    title: "Villas",
    text: "Private gardens shaped around the house: entrance trees, pool planting, shaded terraces and lawns that hold up through a dry summer.",
    image: images.villas,
    alt: "White villa with shuttered windows set among tall trees",
  },
  {
    title: "Hotels and resorts",
    text: "Planting that guests photograph. Arrival courts, pool gardens and restaurant terraces, maintained to a schedule that works around the season.",
    image: images.hotels,
    alt: "Hotel swimming pool surrounded by dense green trees",
  },
  {
    title: "Residences",
    text: "Shared courtyards, rooftop planters and green boundaries for residential buildings, planned for low upkeep and year-round structure.",
    image: images.residences,
    alt: "Residential building with palm trees and a lawn in front",
  },
];

export type Category = "trees" | "flowers" | "vases";

export const categories: {
  id: Category;
  label: string;
  text: string;
  image: string;
  alt: string;
}[] = [
  {
    id: "trees",
    label: "Trees",
    text: "Olive, citrus, cypress and palms, from terrace size to 8 m",
    image: unsplash("1683320553264-e31acd4196e7"),
    alt: "Potted tree standing in front of a building",
  },
  {
    id: "flowers",
    label: "Flowers",
    text: "Flowering plants for the garden and fresh bouquets",
    image: unsplash("1775743093104-d8e53e5ed250"),
    alt: "Flower shop front filled with plants and flowers",
  },
  {
    id: "vases",
    label: "Vases and planters",
    text: "Terracotta, ceramic and stone, for indoors and out",
    image: unsplash("1731413076461-607be6996c9b"),
    alt: "Shelf lined with brown clay vases",
  },
];

// Prices are placeholders. Set price to null to show "Price on request".
export type Product = {
  name: string;
  category: Category;
  detail: string;
  price: string | null;
  tag?: string;
  image: string;
  alt: string;
};

export const products: Product[] = [
  {
    name: "Olive tree",
    category: "trees",
    detail: "Olea europaea, 1.5 to 5 m, potted or planted",
    price: "from €180",
    tag: "Best seller",
    image: unsplash("1762542531473-ec9f86e0d86e"),
    alt: "Small olive tree in a decorative pot",
  },
  {
    name: "Lemon tree",
    category: "trees",
    detail: "Citrus × limon, 1.5 to 3 m, fruiting",
    price: "from €120",
    image: unsplash("1680413557185-2a3da954bbe8"),
    alt: "Row of potted lemon trees along a wall",
  },
  {
    name: "Italian cypress",
    category: "trees",
    detail: "Cupressus sempervirens, 3 to 8 m",
    price: "from €90",
    image: unsplash("1706269771866-728009e647a3"),
    alt: "Row of tall cypress trees along a gravel road",
  },
  {
    name: "Date palm",
    category: "trees",
    detail: "Phoenix canariensis, 2 to 6 m clear trunk",
    price: null,
    image: unsplash("1673964553784-3e34ec90859c"),
    alt: "Palm trees in a sunny park",
  },
  {
    name: "Bougainvillea",
    category: "flowers",
    detail: "Climbing, flowers from spring to autumn",
    price: "from €35",
    tag: "In flower now",
    image: unsplash("1529916005909-d8be62bd4935"),
    alt: "Pink bougainvillea flowers",
  },
  {
    name: "Lavender",
    category: "flowers",
    detail: "Potted, for borders, terraces and paths",
    price: "from €8",
    image: unsplash("1779440158884-fd28651b15dc"),
    alt: "Potted lavender plants on a shelf by a window",
  },
  {
    name: "Hydrangea",
    category: "flowers",
    detail: "Blue, pink or white, for shaded corners",
    price: "from €25",
    image: unsplash("1621518856558-9b2ce2d0660d"),
    alt: "Blue and purple hydrangea flowers",
  },
  {
    name: "Fresh bouquets",
    category: "flowers",
    detail: "Made to order for gifts, hotels and events",
    price: "from €30",
    image: unsplash("1523693916903-027d144a2b7d"),
    alt: "Bouquet of pink and white roses",
  },
  {
    name: "Terracotta urn",
    category: "vases",
    detail: "Hand-thrown clay, 40 to 120 cm",
    price: "from €65",
    tag: "New",
    image: unsplash("1510828561531-05a3388f6d3d"),
    alt: "Three brown clay vases",
  },
  {
    name: "Clay pots",
    category: "vases",
    detail: "Classic shapes, sold singly or in sets",
    price: "from €12",
    image: unsplash("1528789386055-75c4b717bad1"),
    alt: "Brown clay flower pots",
  },
  {
    name: "Ceramic planter",
    category: "vases",
    detail: "Glazed white, frost-resistant, 3 sizes",
    price: "from €45",
    image: unsplash("1613372998667-b83ab5bbe081"),
    alt: "Green plant in a white ceramic pot",
  },
  {
    name: "Decorative urn on stand",
    category: "vases",
    detail: "Ornate clay, for entrances and terraces",
    price: null,
    image: unsplash("1783266256625-441d0dce31b9"),
    alt: "Ornate clay pot on a stand by a textured wall",
  },
];

export const offer = {
  label: "Autumn offer",
  title: "Olive tree and terracotta urn, delivered and planted",
  text: "Autumn is the best time to plant: the soil is still warm and the winter rain does the watering. Choose an olive tree and a hand-thrown urn, and we deliver, plant and set up drip irrigation in one visit.",
  includes: ["Olive tree, 1.5 to 2 m", "Terracotta urn, 60 cm", "Delivery, planting and drip line"],
  price: "€390 for the set",
  image: unsplash("1774554230076-5a67e9bf863a"),
  alt: "Large tree growing in a planter on a cobblestone street",
};

export const perks = [
  {
    title: "Delivery and planting",
    text: "We deliver anything from a single pot to a crane-lifted tree, and plant it for you.",
  },
  {
    title: "Choose in person",
    text: "Visit the nursery and pick the exact tree, flowers and vase you want.",
  },
  {
    title: "Orders for businesses",
    text: "Weekly flowers and planters for hotels, restaurants and events.",
  },
];

export const services = [
  {
    title: "Garden design",
    text: "A measured site survey, a planting plan and 3D views before anything is dug. You see how the garden will look in its first year and in its tenth.",
    points: ["Site survey and soil check", "Planting and lighting plan", "Irrigation layout"],
  },
  {
    title: "Tree supply and planting",
    text: "Mature specimen trees selected from our nursery, delivered by crane truck and planted by our own team with the right soil, staking and drip line.",
    points: ["Specimen trees up to 8 m", "Craning and transport", "Planting guarantee"],
  },
  {
    title: "Flowers for hotels and events",
    text: "Fresh arrangements, seasonal pots and planted displays for lobbies, restaurants, weddings and events, delivered and refreshed on a schedule.",
    points: ["Weekly flower delivery", "Event and wedding displays", "Seasonal pot changes"],
  },
  {
    title: "Garden care",
    text: "Seasonal pruning, feeding, irrigation checks and topiary clipping, on a visit plan agreed with you or your property manager.",
    points: ["Weekly or monthly visits", "Topiary and palm pruning", "Irrigation servicing"],
  },
];

export const gardens = [
  {
    title: "Lawn and pool garden",
    image: unsplash("1782939355736-fc6ed5c24b88"),
    alt: "Wide green lawn beside a swimming pool with lounge chairs",
  },
  {
    title: "Formal hedge garden",
    image: unsplash("1783159144730-abbde99fe3ee"),
    alt: "Formal garden with geometric clipped hedges",
  },
  {
    title: "Stone pond with palms",
    image: unsplash("1789593847924-d418f03a9664"),
    alt: "Stone pond with a rock feature among palm trees",
  },
  {
    title: "Woodland walk",
    image: unsplash("1764260315913-47ba21376cc8"),
    alt: "Wooden path through a lush garden beneath a large tree",
  },
];

export const steps = [
  {
    title: "Site visit",
    text: "We walk the property with you, measure, check soil, sun and access for trucks.",
  },
  {
    title: "Design and quote",
    text: "You receive a planting plan, tree selection and a fixed quote within two weeks.",
  },
  {
    title: "Tree selection",
    text: "Visit the nursery and choose your trees in person, or approve them by video.",
  },
  {
    title: "Planting and care",
    text: "Our team plants, sets up irrigation and stays on for aftercare if you want it.",
  },
];

export const interests = ["Trees", "Flowers", "Vases and planters", "Garden design", "Garden care", "Something else"];
