import { whatsappLink } from "@/lib/content";
import ChatIcon from "./ChatIcon";

/** Always-visible WhatsApp button on small screens. */
export default function FloatingWhatsApp() {
  return (
    <a
      href={whatsappLink("Përshëndetje Luxury Garden, kam një pyetje.")}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Na shkruani në WhatsApp"
      className="eyebrow fixed bottom-5 right-5 z-50 inline-flex h-14 items-center gap-3 bg-brass px-6 text-forest shadow-[0_12px_30px_rgba(15,36,27,0.4)] md:hidden"
    >
      <ChatIcon size={18} />
      WhatsApp
    </a>
  );
}
