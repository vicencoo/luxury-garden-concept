import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond } from "next/font/google";
import "@fontsource-variable/figtree/index.css";
import "./globals.css";

const cormorant = Cormorant_Garamond({
  subsets: ["latin", "latin-ext"],
  weight: ["300", "400", "500"],
  style: ["normal", "italic"],
  variable: "--font-cormorant",
});

export const metadata: Metadata = {
  title: "Luxury Garden | Kopshte, pemë dekorative dhe vazo",
  description:
    "Luxury Garden projekton, mbjell dhe mirëmban kopshte për vila, hotele dhe rezidenca, me ullinj shekullorë, palma, lule natyrale dhe vazo të përzgjedhura.",
};

export const viewport: Viewport = {
  themeColor: "#0f241b",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="sq" className={cormorant.variable}>
      <body className="min-h-full">{children}</body>
    </html>
  );
}
