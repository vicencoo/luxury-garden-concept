// All page copy and photography in one place, so the concept is easy to edit.
// Photos come from the @luxury_gardenn Instagram account (public/ig). They are
// small reel covers; ask the client for the full-size originals before launch.

const ig = (name: string) => `/ig/${name}.jpg`;

export const brand = {
  name: "Luxury Garden",
  phone: "+355 69 776 2580",
  phoneHref: "tel:+355697762580",
  // WhatsApp number in international format, digits only.
  whatsappNumber: "355697762580",
  instagram: "https://www.instagram.com/luxury_gardenn/",
  handle: "@luxury_gardenn",
  followers: "29.3K",
  maps: "https://maps.app.goo.gl/7XKfm1PQHeznwza3A",
};

export function whatsappLink(message: string) {
  return `https://wa.me/${brand.whatsappNumber}?text=${encodeURIComponent(message)}`;
}

export const photos = {
  oliveNight: { src: ig("ulli-nate"), alt: "Ulli shekullor i ndriçuar natën në një kopsht me bar" },
  gardenNight: { src: ig("kopsht-nate"), alt: "Kopsht pranë murit me pemë, juka dhe ndriçim natën" },
  whiteVases: { src: ig("vazo-te-bardha"), alt: "Tri vazo të bardha me reliev gjethesh" },
  nursery: { src: ig("vazo-sera"), alt: "Serrë me rafte plot vazo në ngjyra dheu dhe guri" },
  oliveField: { src: ig("ulli-fushe"), alt: "Ulli i vjetër në fushë nën qiell me re" },
  oliveCrane: { src: ig("ulli-vinc"), alt: "Ulli i madh me rrënjë duke u ngritur me vinç në kamion" },
  rooftopCrane: { src: ig("tarrace-vinc"), alt: "Vinç që ngre një vazo të madhe në tarracë në perëndim të diellit" },
  yucca: { src: ig("juka-vazo"), alt: "Juka në një vazo të rrumbullakët guri me zhavorr" },
  terrace: { src: ig("tarrace-bime"), alt: "Shefler dhe bimë të gjelbra në vazo të zeza në një tarracë natën" },
  palms: { src: ig("furnizim-palma"), alt: "Kamionë të ngarkuar me palma dhe pemë dekorative" },
  cycas: { src: ig("cikas-gure"), alt: "Cikas në një shtrat me gurë të bardhë lumi pranë një ndërtese" },
};

export const navLinks = [
  { href: "#sherbimet", label: "Shërbimet" },
  { href: "#ullinjte", label: "Ullinjtë" },
  { href: "#koleksioni", label: "Koleksioni" },
  { href: "#kontakt", label: "Kontakt" },
];

export const heroFacts = [
  "Projektim dhe zbatim",
  "Ullinj shekullorë dhe palma",
  "Shitje me pakicë dhe shumicë",
];

export const marquee = [
  "Ullinj shekullorë",
  "Palma",
  "Selvi",
  "Vazo artizanale",
  "Lule natyrale",
  "Ndriçim kopshti",
  "Ujitje pikë-pikë",
  "Mirëmbajtje",
];

export const services = [
  {
    title: "Projektim kopshti",
    text: "Studim i terrenit, plan mbjelljeje, ndriçim dhe ujitje. E shihni kopshtin tuaj para se të hapet qoftë edhe një gropë.",
    points: ["Studim i terrenit", "Plan mbjelljeje dhe ndriçimi", "Sistem ujitjeje"],
    photo: photos.cycas,
  },
  {
    title: "Zbatim dhe mbjellje",
    text: "Pemë dhe vazo të mëdha transportohen e ngrihen me vinç, deri në tarracë. I mbjell ekipi ynë, me dheun, mbështetjen dhe ujitjen e duhur.",
    points: ["Pemë të mëdha dhe shekullore", "Transport me vinç", "Mbjellje nga ekipi ynë"],
    photo: photos.rooftopCrane,
  },
  {
    title: "Mirëmbajtje",
    text: "Krasitje, plehërim, kontroll i ujitjes dhe formësim i bimëve, me vizita të rregullta gjatë gjithë vitit.",
    points: ["Vizita javore ose mujore", "Krasitje dhe formësim", "Kujdes sipas stinës"],
    photo: photos.terrace,
  },
  {
    title: "Pemë, lule dhe vazo",
    text: "Ullinj, palma, selvi, lule natyrale dhe vazo të përzgjedhura. Zgjidhini vetë në serrën tonë, me pakicë ose me shumicë.",
    points: ["Pemë dekorative të të gjitha llojeve", "Vazo për brenda dhe jashtë", "Furnizim me shumicë"],
    photo: photos.nursery,
  },
];

export const oliveSteps = [
  {
    numeral: "I",
    title: "Përzgjedhja",
    text: "Çdo ulli e zgjedhim vetë në fushë, sipas formës së kurorës, trungut dhe shëndetit të rrënjëve.",
    photo: photos.oliveField,
  },
  {
    numeral: "II",
    title: "Zhvendosja",
    text: "Pema nxirret me gjithë dheun e rrënjëve dhe transportohet me vinç, pa e lënduar.",
    photo: photos.oliveCrane,
  },
  {
    numeral: "III",
    title: "Vendosja",
    text: "Mbillet në vendin e saj të ri, me ujitje pikë-pikë dhe ndriçim që e nxjerr në pah natën.",
    photo: photos.gardenNight,
  },
];

export const collection = [
  {
    title: "Vazo artizanale",
    text: "Qeramikë, gur dhe fibër, për brenda dhe jashtë",
    photo: photos.whiteVases,
  },
  {
    title: "Bimë dekorative",
    text: "Juka, cikas, agave dhe bimë për tarraca",
    photo: photos.yucca,
  },
  {
    title: "Pemë dhe palma",
    text: "Ullinj, selvi dhe palma, nga vazoja te pema shekullore",
    photo: photos.palms,
  },
];

export const clients = [
  { title: "Vila private", text: "Kopshte, pishina dhe tarraca rreth shtëpisë." },
  { title: "Hotele dhe resorte", text: "Hyrje, pishina dhe ambiente që mysafirët fotografojnë." },
  { title: "Restorante dhe bare", text: "Vazo, gjelbërim dhe ndriçim për ambientet e jashtme." },
  { title: "Rezidenca dhe biznese", text: "Oborre, tarraca dhe gjelbërim me mirëmbajtje të ulët." },
];

export const instagramFeed = [
  photos.oliveNight,
  photos.whiteVases,
  photos.oliveCrane,
  photos.cycas,
  photos.nursery,
  photos.gardenNight,
];

export const interests = [
  "Projektim kopshti",
  "Zbatim dhe mbjellje",
  "Mirëmbajtje",
  "Pemë dhe palma",
  "Vazo dhe bimë",
  "Lule natyrale",
];
