"use client";

import Image from "next/image";
import { useEffect, useState } from "react";
import { categories, perks, products, whatsappLink } from "@/lib/content";
import { SHOP_FILTER_EVENT, type ShopFilter } from "@/lib/shop-filter";
import ChatIcon from "./ChatIcon";

const filters: { id: ShopFilter; label: string }[] = [
  { id: "all", label: "Everything" },
  ...categories.map((c) => ({ id: c.id as ShopFilter, label: c.label })),
];

export default function Shop() {
  const [filter, setFilter] = useState<ShopFilter>("all");

  useEffect(() => {
    const onFilter = (event: Event) => {
      setFilter((event as CustomEvent<ShopFilter>).detail);
    };
    window.addEventListener(SHOP_FILTER_EVENT, onFilter);
    return () => window.removeEventListener(SHOP_FILTER_EVENT, onFilter);
  }, []);

  const visible = filter === "all" ? products : products.filter((p) => p.category === filter);
  const countFor = (id: ShopFilter) =>
    id === "all" ? products.length : products.filter((p) => p.category === id).length;

  return (
    <section id="shop" aria-labelledby="shop-heading" className="scroll-mt-20 bg-chalk">
      <div className="mx-auto max-w-[1320px] px-5 py-24 md:px-10 lg:py-32">
        <div className="grid gap-6 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-7">
            <h2 id="shop-heading" className="font-display text-h2">
              Trees, flowers and vases from our nursery
            </h2>
            <p className="mt-6 max-w-[38rem] text-cypress/80">
              Everything here is in stock at the nursery. Message us on
              WhatsApp for today&apos;s sizes, photos of the exact plant and a
              delivery price.
            </p>
          </div>
        </div>

        <div
          role="group"
          aria-label="Filter products"
          className="-mx-5 mt-12 flex gap-2 overflow-x-auto px-5 pb-1 md:mx-0 md:flex-wrap md:px-0"
        >
          {filters.map((f) => {
            const active = f.id === filter;
            return (
              <button
                key={f.id}
                type="button"
                aria-pressed={active}
                onClick={() => setFilter(f.id)}
                className={`shrink-0 rounded-full border px-5 py-2.5 text-[0.95rem] transition-colors ${
                  active
                    ? "border-cypress bg-cypress text-chalk"
                    : "border-cypress/20 text-cypress hover:border-cypress/60"
                }`}
              >
                {f.label}
                <span className={active ? "ml-2 text-chalk/60" : "ml-2 text-olive"}>
                  {countFor(f.id)}
                </span>
              </button>
            );
          })}
        </div>

        <ul
          key={filter}
          className="settle mt-10 grid grid-cols-2 gap-x-4 gap-y-12 md:grid-cols-3 md:gap-x-8 lg:grid-cols-4"
          style={{ animationDuration: "0.5s" }}
        >
          {visible.map((product) => (
            <li key={product.name} className="flex flex-col">
              <div className="arch relative aspect-[4/5] bg-sage/40">
                <Image
                  src={product.image}
                  alt={product.alt}
                  fill
                  sizes="(min-width: 1024px) 22vw, (min-width: 768px) 30vw, 46vw"
                  className="object-cover"
                />
                {product.tag && (
                  <span className="absolute bottom-3 left-3 rounded-full bg-citrus px-2.5 py-1 text-xs font-medium text-cypress">
                    {product.tag}
                  </span>
                )}
              </div>
              <div className="mt-4 flex flex-1 flex-col items-start">
                <h3 className="font-display text-[1.25rem] leading-tight md:text-[1.4rem]">
                  {product.name}
                </h3>
                <p className="mt-1.5 text-sm leading-snug text-cypress/70">{product.detail}</p>
                <p className="mt-3 font-medium">{product.price ?? "Price on request"}</p>
                <span className="flex-1" />
                <a
                  href={whatsappLink(`Hello Luxury Garden, I would like to ask about: ${product.name}`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`Ask about ${product.name} on WhatsApp`}
                  className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full border border-cypress/25 px-4 py-2 text-sm font-medium transition-colors hover:border-cypress hover:bg-cypress hover:text-chalk sm:w-auto sm:self-start"
                >
                  <ChatIcon size={16} />
                  <span className="sm:hidden">Ask the price</span>
                  <span className="hidden sm:inline">Ask on WhatsApp</span>
                </a>
              </div>
            </li>
          ))}
        </ul>

        <ul className="mt-20 grid gap-8 border-t border-cypress/15 pt-10 md:grid-cols-3">
          {perks.map((perk) => (
            <li key={perk.title}>
              <h3 className="font-display text-[1.3rem]">{perk.title}</h3>
              <p className="mt-2 max-w-[22rem] text-cypress/75">{perk.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
