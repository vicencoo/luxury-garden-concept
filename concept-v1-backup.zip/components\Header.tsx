"use client";

import { useState } from "react";
import Logo from "./Logo";
import ChatIcon from "./ChatIcon";
import { navLinks, whatsappLink } from "@/lib/content";

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-cypress/10 bg-lichen/90 backdrop-blur-md">
      <div className="mx-auto flex h-18 max-w-[1320px] items-center justify-between px-5 md:px-10">
        <a href="#top" aria-label="Luxury Garden, back to top" className="text-cypress">
          <Logo />
        </a>

        <nav aria-label="Main" className="hidden lg:block">
          <ul className="flex items-center gap-8 text-[0.95rem]">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="text-cypress/80 transition-colors hover:text-cypress"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={whatsappLink("Hello Luxury Garden, I have a question.")}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Message us on WhatsApp"
            className="hidden h-11 w-11 items-center justify-center rounded-full border border-cypress/20 transition-colors hover:border-cypress md:inline-flex"
          >
            <ChatIcon />
          </a>
          <a
            href="#contact"
            className="hidden rounded-full bg-cypress px-5 py-2.5 text-[0.95rem] font-medium text-chalk transition-colors hover:bg-cypress-soft sm:inline-block"
          >
            Book a site visit
          </a>
          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-cypress/20 lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            <svg width="18" height="12" viewBox="0 0 18 12" aria-hidden="true">
              {open ? (
                <path d="M3 0l12 12M15 0L3 12" stroke="currentColor" strokeWidth="1.5" />
              ) : (
                <path d="M0 1h18M0 6h18M0 11h18" stroke="currentColor" strokeWidth="1.5" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <nav
          id="mobile-nav"
          aria-label="Mobile"
          className="border-t border-cypress/10 bg-lichen px-5 pb-6 pt-2 lg:hidden"
        >
          <ul className="flex flex-col">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block border-b border-cypress/10 py-4 font-display text-2xl"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="mt-6 inline-block rounded-full bg-cypress px-6 py-3 font-medium text-chalk"
          >
            Book a site visit
          </a>
        </nav>
      )}
    </header>
  );
}
