import Image from "next/image";
import { clients } from "@/lib/content";

export default function Clients() {
  return (
    <section aria-labelledby="clients-heading" className="border-t border-cypress/10">
      <div className="mx-auto max-w-[1320px] px-5 py-24 md:px-10 lg:py-32">
        <div className="grid gap-6 lg:grid-cols-12">
          <h2 id="clients-heading" className="font-display text-h2 lg:col-span-6">
            One team for the whole garden, whatever the property.
          </h2>
          <p className="max-w-[36rem] text-cypress/80 lg:col-span-5 lg:col-start-8 lg:pt-3">
            We design, supply and plant, then look after what we planted. Most
            of our work is for private villas, hotels and residential
            buildings, and each asks something different of a garden.
          </p>
        </div>

        <ul className="mt-16 grid gap-14 md:grid-cols-3 md:gap-8 lg:gap-12">
          {clients.map((client, i) => (
            <li key={client.title} className={i === 1 ? "md:mt-20" : ""}>
              <div className="arch relative aspect-[4/5] bg-sage/40">
                <Image
                  src={client.image}
                  alt={client.alt}
                  fill
                  sizes="(min-width: 768px) 30vw, 100vw"
                  className="object-cover"
                />
              </div>
              <h3 className="mt-7 font-display text-h3">{client.title}</h3>
              <p className="mt-3 max-w-[30rem] text-cypress/75">{client.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
