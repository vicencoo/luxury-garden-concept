"use client";

import { useEffect, useState } from "react";
import Logo from "./Logo";
import { brand, navLinks } from "@/lib/content";

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 text-ivory transition-[background-color,border-color,backdrop-filter] duration-500 ${
        scrolled || open
          ? "border-b border-ivory/10 bg-forest/85 backdrop-blur-xl"
          : "border-b border-transparent"
      }`}
    >
      <div className="mx-auto flex h-20 max-w-[1440px] items-center justify-between px-5 md:px-10">
        <a href="#top" aria-label="Luxury Garden, kthehu në fillim">
          <Logo />
        </a>

        <nav aria-label="Kryesore" className="hidden lg:block">
          <ul className="flex items-center gap-10">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="eyebrow relative text-ivory/75 transition-colors after:absolute after:-bottom-1.5 after:left-0 after:h-px after:w-0 after:bg-brass after:transition-all after:duration-500 hover:text-ivory hover:after:w-full"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-6">
          <a href={brand.phoneHref} className="hidden text-sm tracking-wide text-ivory/75 transition-colors hover:text-ivory xl:inline">
            {brand.phone}
          </a>
          <a
            href="#kontakt"
            className="eyebrow hidden border border-brass/60 px-6 py-3.5 text-ivory transition-colors duration-500 hover:bg-brass hover:text-forest sm:inline-block"
          >
            Kërko ofertë
          </a>
          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center lg:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Mbyll menunë" : "Hap menunë"}
            onClick={() => setOpen((v) => !v)}
          >
            <svg width="26" height="12" viewBox="0 0 26 12" aria-hidden="true">
              {open ? (
                <path d="M5 0l16 12M21 0L5 12" stroke="currentColor" strokeWidth="1.2" />
              ) : (
                <path d="M0 1h26M8 11h18" stroke="currentColor" strokeWidth="1.2" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <nav id="mobile-nav" aria-label="Menuja" className="grain h-[calc(100svh-5rem)] bg-forest px-5 pb-10 pt-6 lg:hidden">
          <ul className="flex flex-col">
            {navLinks.map((link, i) => (
              <li key={link.href} className="settle" style={{ animationDelay: `${0.05 * i}s` }}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="flex items-baseline gap-5 border-b border-ivory/10 py-5 font-display text-4xl font-light"
                >
                  <span className="font-sans text-xs text-brass">0{i + 1}</span>
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <a href={brand.phoneHref} className="mt-10 block font-display text-2xl text-brass-soft">
            {brand.phone}
          </a>
        </nav>
      )}
    </header>
  );
}
